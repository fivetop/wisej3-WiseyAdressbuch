﻿using System;
using Wisej.Web;

namespace WiseyAdressbuch
{
    public partial class MyDesktop : Desktop
    {
        public MyDesktop()
        {
            InitializeComponent();
        }
    }
}
