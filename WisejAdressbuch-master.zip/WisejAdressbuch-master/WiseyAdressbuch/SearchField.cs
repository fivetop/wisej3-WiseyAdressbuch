﻿using System;
using Wisej.Web;

namespace WiseyAdressbuch
{
    public partial class SearchField : Wisej.Web.UserControl
    {    
        
        public SearchField()
        {
            InitializeComponent();            
            
        }
    }
}
